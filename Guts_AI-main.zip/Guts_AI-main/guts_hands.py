# guts_hands.py - GUTS Hands for live_voice_17 - NO pip needed
import subprocess, time
from pathlib import Path
import pyautogui

def set_volume(level: str) -> str:
    try:
        lvl = max(0, min(100, int(level)))
        try:
            from ctypes import cast, POINTER
            from comtypes import CLSCTX_ALL
            from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
            devices = AudioUtilities.GetSpeakers()
            interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
            volume = cast(interface, POINTER(IAudioEndpointVolume))
            volume.SetMasterVolumeLevelScalar(lvl/100, None)
            return f"Volume set to {lvl}%"
        except:
            pyautogui.press("volumemute" if lvl==0 else "volumeup")
            return f"Volume key pressed for {lvl}%"
    except Exception as e: return f"Volume error: {e}"

def set_brightness(level: str) -> str:
    try:
        import screen_brightness_control as sbc
        sbc.set_brightness(max(0,min(100,int(level))))
        return f"Brightness {level}%"
    except: return "Brightness needs screen-brightness-control"

def take_screenshot(name: str = "screenshot") -> str:
    path = Path.home() / "Desktop" / f"{name}_{time.strftime('%H%M%S')}.png"
    pyautogui.screenshot(str(path))
    return f"Screenshot saved: {path}"

def system_power(action: str) -> str:
    a = action.lower().strip()
    if a == "lock": subprocess.Popen("rundll32.exe user32.dll,LockWorkStation", shell=True); return "PC Locked"
    if a == "sleep": subprocess.Popen("rundll32.exe powrprof.dll,SetSuspendState 0,1,0", shell=True); return "Sleeping..."
    if a == "shutdown": subprocess.Popen("shutdown /s /t 5", shell=True); return "Shutdown in 5 sec"
    if a == "restart": subprocess.Popen("shutdown /r /t 5", shell=True); return "Restart in 5 sec"
    return "Use: lock, sleep, shutdown, restart"

def media_control(action: str) -> str:
    m = {"play_pause":"playpause","next":"nexttrack","prev":"prevtrack","volume_up":"volumeup","volume_down":"volumedown","mute":"volumemute"}
    k = m.get(action.lower().strip())
    if not k: return "Use: play_pause, next, prev"
    pyautogui.press(k); return f"Media {action} done"

def press_hotkey(keys: str) -> str:
    pyautogui.hotkey(*[k.strip() for k in keys.split("+")]); return f"Pressed {keys}"

def type_text(text: str) -> str:
    pyautogui.typewrite(text, interval=0.02); return f"Typed {text[:50]}"